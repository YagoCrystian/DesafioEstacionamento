﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Seja bem-vindo ao sistema de estacionamento!");

        // Instancia o estacionamento com valores iniciais
        decimal precoInicial;
        decimal precoPorHora;

        // Loop para garantir que o usuário insira um valor válido para precoInicial
        while (true)
        {
            Console.WriteLine("Digite o preço inicial:");
            if (decimal.TryParse(Console.ReadLine(), out precoInicial))
                break;
            else
                Console.WriteLine("Valor inválido. Por favor, insira um valor numérico.");
        }

        // Loop para garantir que o usuário insira um valor válido para precoPorHora
        while (true)
        {
            Console.WriteLine("Digite o preço por hora:");
            if (decimal.TryParse(Console.ReadLine(), out precoPorHora))
                break;
            else
                Console.WriteLine("Valor inválido. Por favor, insira um valor numérico.");
        }

        Estacionamento estacionamento = new Estacionamento(precoInicial, precoPorHora);

        string opcao;
        do
        {
            Console.WriteLine("\nDigite a sua opção:");
            Console.WriteLine("1 - Cadastrar veículo");
            Console.WriteLine("2 - Remover veículo");
            Console.WriteLine("3 - Listar veículos");
            Console.WriteLine("4 - Encerrar");

            opcao = Console.ReadLine() ?? string.Empty;

            switch (opcao)
            {
                case "1":
                    estacionamento.AdicionarVeiculo();
                    break;

                case "2":
                    estacionamento.RemoverVeiculo();
                    break;

                case "3":
                    estacionamento.ListarVeiculos();
                    break;

                case "4":
                    Console.WriteLine("Encerrando o programa...");
                    break;

                default:
                    Console.WriteLine("Opção inválida! Tente novamente.");
                    break;
            }

        } while (opcao != "4");
    }
}
